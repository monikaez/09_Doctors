<?php
include "inc/config.php";
include "inc/classes.php";

if(isset($_POST['action']) AND $_POST['action'] == "save"){
    $insert['client'] = strip_tags(htmlspecialchars( $_POST['client']));
    $insert['doc_id'] = (int)$_POST['doc_id'];
    $insert['vacant_id'] = (int)$_POST['vacant_id'];
    $insert['notes'] = strip_tags(htmlspecialchars($_POST['notes']));

    $db = new DB;
    $stmt = "INSERT INTO reservations (client, doc_id, vacant_id, notes, active) VALUES (:client, :doc_id, :vacant_id, :notes, 1)";
       
    $update['res_id'] = $db->Insert($stmt, $insert);
    $update['id'] =  $insert['vacant_id'];
    
    $stmt = "UPDATE vacants SET res_id = :res_id WHERE id = :id";
    $u = $db->Update($stmt,$update );
    if ($u){
        echo "Часът е запазен !";
    }else{
        echo "Грешка при запис";
    }
}


// var_dump($_POST);
echo "ok";