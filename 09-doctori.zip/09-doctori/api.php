<?php
include "inc/config.php";
include "inc/classes.php";

//det all Docs
if(isset($_GET['getDocs'])){
    $db = new DB;
    $stmt = "SELECT * FROM doctors WHERE active=1";
    $doctors = $db->select($stmt);
    if(isset($_GET['type']) AND $_GET['type'] == "html"){
        $html = '<option selected disable>Изберете...</option>';
        foreach($doctors AS $doc){
            $html .="<option value='".$doc['id']."'>".$doc['names']." (".$doc['specialty'].") </option>";
        }
    echo $html;
    }else{
        echo json_encode($doctors, JSON_UNESCAPED_UNICODE);
    }
}
if(isset($_GET['Doc_id'])){
    $param['doc_id'] = (int) $_GET['Doc_id'];
    $param['next_free'] = (int) $_GET['next_free'];
    $stmt = "SELECT * FROM vacants WHERE active=1 AND res_id = 0 AND doc_id = :doc_id AND date_hour > NOW() AND date_hour < DATE_ADD(NOW(), INTERVAL :next_free DAY)";
    $db = new DB;
    $result = $db->Select($stmt, $param);
    
        if(isset($_GET['type']) AND $_GET['type'] == "html"){
            $html = '';
            if(count($result) >0){
                foreach($result AS $vac){
                    $html .= '<input type="radio" class="form-check-input" name="vacant_id" value="'.$vac['id'].'" >'.date('h:i(d.m.Y г.)',strtotime($vac['date_hour']))."<br>";
                }
                $html .= '';
                echo $html;
            }else{
                echo "Няма свободни часове!";
            }
        }else{
            if(count($result) > 0){
                echo json_encode($result, JSON_UNESCAPED_UNICODE);
            }else{
                echo json_encode(['error'=>"Няма свободни часове"], JSON_UNESCAPED_UNICODE);
            }
               
        }   
    
}



// <option value="1">Proba</option>