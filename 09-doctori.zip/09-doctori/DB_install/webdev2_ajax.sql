-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Време на генериране: 15 фев 2022 в 18:43
-- Версия на сървъра: 10.4.18-MariaDB
-- Версия на PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данни: `webdev2_ajax`
--

-- --------------------------------------------------------

--
-- Структура на таблица `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `names` varchar(120) NOT NULL,
  `specialty` varchar(200) NOT NULL,
  `notes` varchar(300) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `doctors`
--

INSERT INTO `doctors` (`id`, `names`, `specialty`, `notes`, `active`) VALUES
(1, 'Иван Иванов', 'УНГ', '', 1),
(2, 'Георги Георгиев', 'Зъболекар', '', 1),
(3, 'Марин Маринов', 'Гастроентеролог', '', 1),
(4, 'Мария Маринова', 'Вътрешни болести', '', 1);

-- --------------------------------------------------------

--
-- Структура на таблица `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `vacant_id` int(11) NOT NULL,
  `notes` varchar(300) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Структура на таблица `vacants`
--

CREATE TABLE `vacants` (
  `id` int(11) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `date_hour` datetime NOT NULL,
  `res_id` int(11) NOT NULL,
  `notes` varchar(300) NOT NULL,
  `active` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `vacants`
--

INSERT INTO `vacants` (`id`, `doc_id`, `date_hour`, `res_id`, `notes`, `active`) VALUES
(1, 1, '2022-02-16 10:00:00', 0, '', 1),
(2, 1, '2022-02-16 11:00:00', 0, '', 1),
(3, 1, '2022-02-16 12:00:00', 0, '', 1),
(4, 2, '2022-02-16 08:00:00', 0, '', 1),
(5, 2, '2022-02-16 08:30:00', 0, '', 1),
(6, 2, '2022-02-16 09:00:00', 3, '', 1),
(7, 2, '2022-02-16 09:30:00', 2, '', 1),
(8, 3, '2022-02-16 16:00:00', 0, '', 1),
(9, 3, '2022-02-16 16:15:00', 0, '', 1),
(10, 3, '2022-02-16 16:30:00', 0, '', 1),
(11, 3, '2022-02-16 16:45:00', 0, '', 1),
(12, 4, '2022-02-17 10:00:00', 0, '', 1),
(13, 4, '2022-02-17 10:40:00', 0, '', 1),
(14, 4, '2022-02-17 11:20:00', 0, '', 1),
(15, 4, '2022-02-17 13:00:00', 0, '', 1);

--
-- Indexes for dumped tables
--

--
-- Индекси за таблица `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `vacants`
--
ALTER TABLE `vacants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vacants`
--
ALTER TABLE `vacants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
