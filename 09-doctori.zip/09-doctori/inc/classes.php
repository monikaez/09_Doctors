<?php
defined('SITE') OR exit('Неразрешен достъп');

//calss Page

class Page {
    function __construct(){
        require_once 'inc/config.php';
    }

    // create var-s from DATA array
    public function load_template($name='', $data=array()){
        if(count($data)>0){
            foreach($data AS $key=>$value){
                $$key = $value;
            }
        }

        // load template file
        if(file_exists(SITE_ROOT.'template/'.$name.'.php')){
            include SITE_ROOT.'template/'.$name.'.php';
        }else{
            exit('Файлът:'.SITE_ROOT.'template/'.$name.'.php не е намерен');
        }
    }

    

}

class ConnectDB{
    private static $instance = null;
    private $connection;

    private $dbhost = DB_SERVER;
    private $dbname = DB_DATABASE;
    private $username = DB_USER;
    private $password = DB_PASS;

    private function __construct(){
        try{
            $this->connection = new PDO("mysql:host={$this->dbhost};
                                    dbname={$this->dbname}",
                                    $this->username,
                                    $this->password,
                                    array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES 'utf8'")
                                );
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
        
    }

    public function getConnection(){
        return $this->connection;
    }

    public static function getInstance(){
        if(!self::$instance){
            self::$instance = new ConnectDB();
        }
        return self::$instance;
    }
}


class DB {
    private $connection = null;
    // connect to database
    public function __construct(){
        $instance = ConnectDB::getInstance();
        $this->connection = $instance->getConnection();
    }

    private function executeStatement($statement,$parameters){
        try{
            $stmt = $this->connection->prepare($statement);
            $stmt->execute($parameters);
            return $stmt;
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
    }
    
    public function Select($statement='',$parameters=array()){
        try{
            $result = $this->executeStatement($statement,$parameters);
            return $result->fetchAll();
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    public function Insert($statement='',$parameters=array()){
        try{
            $this->executeStatement($statement,$parameters);
            return $this->connection->lastInsertId();
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    public function Update($statement='',$parameters=array()){
        try{
            $this->executeStatement($statement,$parameters);
            return true;
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    public function Delete($statement='',$parameters=array()){
        try{
            $this->executeStatement($statement,$parameters);
            return true;
        }catch(Exception $e){
            throw new Exception($e->getMessage());
        }
    }

}








 