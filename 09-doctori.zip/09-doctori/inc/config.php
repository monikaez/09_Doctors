<?php
define('SITE',true);
//define Base URL
define('BASE_URL','/webdev/09_doctori/');

//site title
define('SITE_TITLE','платформа');


//define base path
define('SITE_ROOT', "D:\\xampp\\htdocs\\webDev\\09_doctori\\" );


//database
define('DB_SERVER','localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_DATABASE', '09_doctori');